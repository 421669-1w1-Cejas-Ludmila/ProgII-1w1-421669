﻿using Act_4_entrega.Interfaces;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Act_4_entrega.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnviosController : ControllerBase
    {
        private readonly IEnvioRepository _envioRepository;
        public EnviosController(IEnvioRepository envioRepository) 
        { 
            _envioRepository = envioRepository;
        }
        // GET: api/<EnviosController>
        [HttpGet]
        public IActionResult GetEnvios([FromQuery] string? direccion, [FromQuery] string? estado)
        {
            try
            {
                return Ok(_envioRepository.GetEnvios(direccion, estado));
            }
            catch (Exception)
            {
                return StatusCode(500, new { mensaje = "Error al obtener los envíos." });
            }
        }

        // DELETE api/<EnviosController>/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                var eliminado = _envioRepository.Delete(id);

                if (eliminado)
                    return Ok(new { mensaje = "Envío cancelado exitosamente." });

                return NotFound(new { mensaje = "No se encontró el envío." });
            }
            catch (Exception)
            {
                return StatusCode(500, new { mensaje = "Error al cancelar el envío." });
            }
        }

    }
}
