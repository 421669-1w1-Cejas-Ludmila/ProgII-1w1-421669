﻿using Act_4_entrega.Models;

namespace Act_4_entrega.Interfaces
{
    public interface IEnvioRepository
    {
        List<Envio> GetEnvios(string? direccion, string? estado);
        bool Delete(int id);
        Envio? GetById (int id);
    }
}
