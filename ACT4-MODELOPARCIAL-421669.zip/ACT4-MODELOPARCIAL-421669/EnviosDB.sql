
IF DB_ID('EnviosDB') IS NULL
BEGIN
    CREATE DATABASE EnviosDB;
END
GO

USE EnviosDB;
GO

IF OBJECT_ID('Producto','U') IS NULL
BEGIN
CREATE TABLE Producto (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    Precio DECIMAL(18,2) NOT NULL
);
END
GO

IF OBJECT_ID('Envio','U') IS NULL
BEGIN
CREATE TABLE Envio (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Fecha DATETIME NOT NULL,
    DniCliente NVARCHAR(20) NOT NULL,
    Direccion NVARCHAR(200) NOT NULL,
    PalabraSecreta NVARCHAR(50) NULL,
    Estado NVARCHAR(50) NOT NULL
);
END
GO


IF OBJECT_ID('DetalleEnvio','U') IS NULL
BEGIN
CREATE TABLE DetalleEnvio (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    EnvioId INT NOT NULL,
    ProductoId INT NOT NULL,
    Cantidad INT NOT NULL,
    Comentario NVARCHAR(200) NULL,
    CONSTRAINT FK_DetalleEnvio_Envio FOREIGN KEY (EnvioId) REFERENCES Envio(Id),
    CONSTRAINT FK_DetalleEnvio_Producto FOREIGN KEY (ProductoId) REFERENCES Producto(Id)
);
END
GO

INSERT INTO Producto (Nombre, Precio) VALUES ('Producto A', 100), ('Producto B', 250);
INSERT INTO Envio (Fecha, DniCliente, Direccion, PalabraSecreta, Estado) 
VALUES (GETDATE(), '12345678', 'Calle Falsa 123', 'secreto', 'Pendiente');
INSERT INTO DetalleEnvio (EnvioId, ProductoId, Cantidad, Comentario) 
VALUES (1, 1, 2, 'Primera entrega'), (1, 2, 1, 'Segunda entrega');


INSERT INTO Producto (Nombre, Precio) VALUES 
('Producto C', 150),
('Producto D', 300),
('Producto E', 75),
('Producto F', 500);

INSERT INTO Envio (Fecha, DniCliente, Direccion, PalabraSecreta, Estado) VALUES
(GETDATE(), '87654321', 'Av. Siempre Viva 742', 'clave1', 'Enviado'),
(GETDATE(), '11223344', 'Calle Luna 55', 'clave2', 'Pendiente'),
(GETDATE(), '99887766', 'Calle Sol 12', 'clave3', 'Cancelado'),
(GETDATE(), '44556677', 'Calle Estrella 89', 'clave4', 'Pendiente');


INSERT INTO DetalleEnvio (EnvioId, ProductoId, Cantidad, Comentario) VALUES
(2, 3, 1, 'Entrega r�pida'),
(2, 1, 2, 'Cliente VIP'),
(3, 4, 1, 'Entregar en mano'),
(3, 5, 3, 'Empaque delicado'),
(4, 2, 2, 'Urgente'),
(4, 6, 1, 'Prioridad alta');

