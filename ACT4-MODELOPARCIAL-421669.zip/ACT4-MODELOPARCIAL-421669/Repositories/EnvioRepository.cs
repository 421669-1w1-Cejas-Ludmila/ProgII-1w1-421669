﻿using Act_4_entrega.Interfaces;
using Act_4_entrega.Models;

namespace Act_4_entrega.Repositories
{
    public class EnvioRepository : IEnvioRepository
    {
        private readonly EnviosDBContext _context;

        public EnvioRepository (EnviosDBContext context)
        {
            _context = context;
        }
        public bool Delete(int id)
        {
            var envio = GetById(id);
            if(envio != null && envio.Estado != "Cancelado")
            {
                envio.Estado = "Cancelado";
                _context.Envios.Update(envio);
                return _context.SaveChanges() > 0;
            }
            return false;
        }

        public Envio? GetById(int id)
        {
            return _context.Envios.Find(id);
        }

        public List<Envio> GetEnvios(string? direccion, string? estado)
        {
            var envios = _context.Envios.ToList();
            if (!string.IsNullOrEmpty(direccion))
            {
                envios = envios.Where(e => e.Direccion.Contains(direccion)).ToList();
            }
            if (!string.IsNullOrEmpty(estado))
            {
                envios = envios.Where(e => e.Estado.Contains(estado)).ToList();
            }
            return envios;
                
         }
        }
    }

